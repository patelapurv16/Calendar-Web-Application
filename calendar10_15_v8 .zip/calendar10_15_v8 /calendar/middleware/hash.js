module.exports = function(string){
  return string;
}
