var fs = require('fs');
var hash = require('./hash.js')
var path = require('path');
var userPath = path.join(__dirname, "..", "storage", "users.json");
var users = require(userPath);

function check(user, pass){
  var data = null;
  try{
    data = fs.readFileSync(userPath, 'utf-8');
  }catch(err){
    //console.log(err);
    return false;
  }


  var json = JSON.parse(data);
  var ret = false;
  //console.log(json[user]);

  if(json[user] && (!pass || json[user].password == hash(pass))){
    return true;
  }

  //console.log(ret);
  return ret;
}

function create(user){
    //console.log("/createUser");
    var response = {};

    //user.password = hash(user.password);

    if(!check(user.username, user.password)){
      response.status = true;
      response.page = '/login';
      fs.readFile(userPath, 'utf-8', function(err, data) {
        if (err) {
          //console.log(err);
          throw err;
        }
        var arrayOfObjects = JSON.parse(data);
        arrayOfObjects[user.username] = user;
        //console.log(arrayOfObjects);
        fs.writeFile(userPath, JSON.stringify(arrayOfObjects, null, 4), function(err) {
          if (err) throw err
          //console.log('Done!');
        })
      })
    }else{
      response.status = false;
      response.message = "Username or password are invalid, or user already exists";
      //console.log("failed");
    }
    return response;
}

function addEvent(user){
  //console.log("/addEvent");
  //console.log(user);
  var data;
  try{
    data = fs.readFileSync(userPath, 'utf-8');
    var arrayOfObjects = JSON.parse(data);
    if(!arrayOfObjects[user.username].events){
      arrayOfObjects[user.username].events = [user.events];
    }else{
      arrayOfObjects[user.username].events.push(user.events);
    }
    //console.log(arrayOfObjects);
    fs.writeFile(userPath, JSON.stringify(arrayOfObjects, null, 4), function(err) {
      if (err){
        //console.log(err);
        throw err;
      }
      //console.log('Done!');
    });
  }catch(err){
    //console.log(err);
    return err;
  }
}

function deleteEvent(username, eventNum){
  //console.log("/deleteEvent");
  //console.log(eventNum);
  var data;
  try{
    data = fs.readFileSync(userPath, 'utf-8');
    var arrayOfObjects = JSON.parse(data);
    arrayOfObjects[username].events.splice(eventNum, 1);
    //console.log(arrayOfObjects);
    fs.writeFile(userPath, JSON.stringify(arrayOfObjects, null, 4), function(err) {
      if (err){
        //console.log(err);
        throw err;
      }
      //console.log('Done!');
    });
  }catch(err){
    //console.log(err);
    return err;
  }

}

var userManager = {
  checkUser: check,
  createUser: create,
  addEvent: addEvent,
  deleteEvent : deleteEvent
}


module.exports = userManager;
